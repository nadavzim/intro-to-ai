LEFT = 0
ROOT = 1
RIGHT = 2

'''
Reads file fname to the list ds.
Each line in the file contains comma seperated numbers (the attributes)
and the class (the last value in the line.)
'''
def readDataset(fname):
    f = open(fname, "r")
    ds = []
    s = f.readline()
    while s != "":
        ds += [[]]
        s=s.split(",")
        for i in s[:-1]:
            ds[-1] += [float(i)]
        ds[-1] += [s[-1]]
        s = f.readline()
    return ds

'''
returns a list of all the classes in the dataset.
'''
def classes(ds):
    cls = []
    for i in ds:
        if not(i[-1] in cls):
            cls += [i[-1]]
    return cls

'''
Returns the gini criterion of ds[start...mid] and ds[mid+1...end-1]
'''
def gini(ds, classes, mid):
    
    # YOUR CODE HERE

    return (0) 
'''
Returns the attribute on which to split and the split value
'''
def chooseSplit(ds, classes):
    
    splitPoint = [0,ds[0][0]]   # YOUR CODE HERE
    
    return splitPoint
    
'''
Returns the majority class in ds
'''
def majority(ds, classes):
    count = [0] * len(classes)
    for i in ds:
        count[classes.index(i[-1])] += 1
    return classes[count.index(max(count))]

'''
Returns True iff all instances id ds have the same class
'''
def allTheSameClass(ds):
    cls = ds[0][-1] 
    for i in ds:
        if i[-1] != cls:
            return False
    return True
        
'''
Builds the decision tree. A leaf has at most leafSize instances
'''
def buildTree(ds, classes, leafSize = 1):

     # YOUR CODE HERE
    
    return [ds[0][-1]]

def buildClassifier(fname, leafSize = 1):
    ds = readDataset(fname)
    cls = classes(ds)
    return buildTree(ds, cls, leafSize)

def classify(dt, instance):
    if len(dt) == 1:
        return dt[0]
    if instance[dt[ROOT][0]] <= dt[ROOT][1]:
        return classify(dt[LEFT], instance)
    return classify(dt[RIGHT], instance)
    

dt = buildClassifier("iris-training.txt", 70)
print(dt)
ds = readDataset("iris-testing.txt")
c = 0
for i in ds:
    if classify(dt, i[:-1]) == i[-1]:
        c = c + 1
print (c)
